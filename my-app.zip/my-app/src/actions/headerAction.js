import { headerActionType } from '../actionTypes';
const actions={
    headerNameUpdate:(payload)=>({
        type:headerActionType.HEADERNAME,
        data:payload
    })     
};

export const headerNameUpdate=(data)=>(dispatch,getState)=>{
      dispatch(actions.headerNameUpdate(data));  
}