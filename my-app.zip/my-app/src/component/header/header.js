import React,{ Component,Fragment } from 'react';
import {
  Card, CardImg, CardText, CardBody,
  CardTitle, CardSubtitle, Button
} from 'reactstrap';

class Header extends Component{
     constructor(props){
         super(props);
         this.state={
             headerName:'DefaultName'
         }
       
     };
     updateHandle=(e)=>{
        e.preventDefault();
         console.log('Event Tiggered');
       this.setState({
           headerName:'HeaderUpdatedWithHelpOfRedux'
       });
       debugger;
       this.props.actions.headerNameUpdate('twe');
     }
    render()   
    {
        const { header } =this.props
        return(
            <Fragment>
                <div>{ header.headerName }</div>
                <Button color="primary" onClick={this.updateHandle}>UpdateName</Button>
            </Fragment>
          
        )
    }

}
export default Header;