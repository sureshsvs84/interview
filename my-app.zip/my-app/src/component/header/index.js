import Header from './header';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {headerNameUpdate} from '../../actions/headerAction'
const mapStateToProps=(state)=>{
    debugger;
    return{
        header:state.rootReducer.HeaderReducer
    }
   
}
const mapDispatchToProps=(dispatch)=>{
    return{
        actions:bindActionCreators({
            headerNameUpdate
        }, dispatch)
       
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(Header);
