import { combineReducers } from 'redux';
import { HeaderReducer } from '../reducer/headerReducer';

export default combineReducers({
    HeaderReducer,
   
});