import { headerActionType } from "../actionTypes";
const initialState = {headerName:'Interview Sample'};
export const HeaderReducer = (state = initialState, action) => {   
    const {type,data} = action
    switch (type) {
      case headerActionType.HEADERNAME: {         
          state={
              ...state,
              headerName:data
          }
        return state;
      }
      default: {
        return state;
      }
    }
  };
 