import { combineReducers } from "redux";
import rootReducer from "./reducer/appReducer";


export default combineReducers({ rootReducer });
