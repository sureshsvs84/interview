export const headerActionType={
 HEADERNAME:'HEADERNAME'
}